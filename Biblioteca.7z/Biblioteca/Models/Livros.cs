﻿using System.Diagnostics.Eventing.Reader;

namespace Biblioteca.Models
{
    public class Livros
    {
        public int id { get; set; }
        public int idVenda { get; set; }
        public int idDevolucao { get; set; }
        public string titulo { get; set; } = string.Empty;
        public string autor { get; set; } = string.Empty;
        public int quantidade { get; set; }
        public int preco { get; set; }
    }

    public class Locacao
    {

        public string Nome { get; set; } = string.Empty;
        public DateTime DataNascimento { get; set; } 
        public int IdLocatario { get; set; }
    }
}
