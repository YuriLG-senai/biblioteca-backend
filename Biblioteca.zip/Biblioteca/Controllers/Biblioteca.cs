﻿using Biblioteca.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Biblioteca : ControllerBase
    {
        private static List<Livros> livro = new List<Livros>

        {
          new Livros
           {
                id = 1,
                idVenda = 1,
                idDevolucao = 1,
                titulo = "Dom Casmurro",
                autor = "Machado de Assis",
                quantidade = 2,
                preco = 40,
           },
          new Livros
          {
              id = 2,
              idVenda = 2,
              idDevolucao = 2,
              titulo = "Memórias Póstumas de Brás Cubas",
              autor = "Machado de Assis",
              quantidade = 3,
              preco = 50
          },
          new Livros
          {
              id = 3,
              idVenda = 3,
              idDevolucao = 3,
              titulo = "Grande Sertão: Veredas",
              autor = "João Guimarães Rosa",
              quantidade = 4,
              preco = 100

          },
          new Livros
          {
              id = 4,
              idVenda = 4,
              idDevolucao = 4,
              titulo = "O Cortiço",
              autor = "Aluísio Azevedo",
              quantidade = 4,
              preco = 90
          },
          new Livros
          {
              id = 5,
              idVenda = 5,
              idDevolucao = 5,
              titulo = "Iracema",
              autor = "José de Alencar",
              quantidade = 1,
              preco = 30
          },
          new Livros
          {
              id = 6,
              idVenda = 6,
              idDevolucao = 6,
              titulo = "Macunaíma",
              autor = "Mário de Andrade",
              quantidade = 11,
              preco = 60
          },
          new Livros
          {
              id = 7,
              idVenda = 7,
              idDevolucao = 7,
              titulo = "Capitães da Areia",
              autor = "Jorge Amado",
              quantidade = 2,
              preco  = 80
          },
          new Livros
          {
             id = 8,
             idVenda = 8,
             idDevolucao = 8,
             titulo = "Vidas Secas",
             autor = "Graciliano Ramos",
             quantidade = 9,
             preco = 90
          },
          new Livros
          {
              id = 9,
              idVenda = 9,
              idDevolucao = 9,
              titulo = "A Moreninha",
              autor = "Joaquim Manuel de Macedo",
              quantidade = 2,
              preco = 50
          },
          new Livros
          {
              id = 10,
              idVenda = 10,
              idDevolucao = 10,
              titulo = "O Tempo e o Vento",
              autor = "Erico Verissimo",
              quantidade = 1,
              preco = 120
          },
          new Livros
          {
              id = 11,
              idVenda = 11,
              idDevolucao = 11,
              titulo = "A Hora da Estrela",
              autor = "Clarice Lispector",
              quantidade = 1,
              preco = 90
          },
          new Livros
          {
              id = 12,
              idVenda = 12,
              idDevolucao = 12,
              titulo = "O Quinze",
              autor = "Rachel de Queiroz",
              quantidade = 1,
              preco = 90
          },
          new Livros
          {
              id = 13,
              idVenda = 13,
              idDevolucao = 13,
              titulo = "Menino do Engenho",
              autor = "José Lins do Rego",
              quantidade = 5,
              preco = 170
          },
          new Livros
          {
              id = 14,
              idVenda = 14,
              idDevolucao = 14,
              titulo = "Sagarana",
              autor = "João Guimarães Rosa",
              quantidade = 3,
              preco = 95
          },
          new Livros
          {
              id = 15,
              idVenda = 15,
              idDevolucao = 15,
              titulo = "Fogo Morto",
              autor = "José Lins do Rego",
              quantidade = 1,
              preco = 45
          },
        };

        [HttpGet]
        public ActionResult<List<Livros>>
            diagnosticoLivros()
        {
            return Ok(livro);
        }

        [HttpPut("locacao/{idVenda}")]
        public ActionResult<List<Livros>>
            locarLivro(int idVenda)
        {
            var pesquisa = livro.Find(y => y.idVenda == idVenda);

            if (pesquisa is null)
                return NotFound("Livro não encontrado");
            pesquisa.quantidade--;

            if (pesquisa.quantidade <= -1) { 
                pesquisa.quantidade = 0;
                return BadRequest("Quantidade insuficiente.");
            }
            pesquisa.locado = true;

            return Ok(pesquisa);
        }

        [HttpGet("consulta/{id}")]
        public ActionResult<List<Livros>>
       consultarLivro(int id)
        {
            var pesquisa = livro.Find(x => x.id == id);

            if (pesquisa is null)
                return NotFound("Livro não encontrado");

            return Ok(new
            {
                pesquisa.titulo,
                pesquisa.autor,
                pesquisa.locado,
                pesquisa.quantidade
            });
        }

        [HttpGet("autor/{autor}" )]
        public ActionResult<List<Livros>> 
        pesquisaTitulo(string autor)
        {
            var resultado = new List<Livros>();

            foreach (var item in livro)
            {
                if (!string.IsNullOrEmpty(autor) &&
                    item.autor.Contains(autor,StringComparison.OrdinalIgnoreCase))
                {
                    resultado.Add(item);
                }
            }

            if (resultado.Count == 0)
                return NotFound("Autor não encontrado.");
             
            return Ok(resultado);
            
             
                
             
        }

        [HttpPut("devolucao/{idDevolucao}")]
        public ActionResult<List<Livros>>
            devolverLivro(int idDevolucao)
        {
            var livroDevolver = livro.Find(z => z.id == idDevolucao);

            if (livroDevolver is null)
                return NotFound("Livro não encontrado.");


            livroDevolver.locado = false;

            livroDevolver.quantidade++;

            return Ok(new
            {
                livroDevolver.titulo,
                livroDevolver.locado,
                livroDevolver.quantidade
            });
        }

    }
       
}


