﻿using System.Diagnostics.Eventing.Reader;

namespace Biblioteca.Models
{
    public class Livros
    {
        public int id { get; set; }
        public int idVenda { get; set; }
        public int idDevolucao { get; set; }
        public string titulo { get; set; } = string.Empty;
        public string autor { get; set;} = string.Empty;
        public bool locado { get; set; } = false;
        public int quantidade { get; set; }
        public int preco { get; set; }
    }
}
